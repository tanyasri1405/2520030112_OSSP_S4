
#define _GNU_SOURCE
#include <arpa/inet.h>
#include <dirent.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#define PORT 8080
#define REQUEST_MAX 262144
#define MAX_SESSIONS 64

typedef struct {
    int used;
    char token[64];
    char email[160];
    char name[120];
    char role[24];
} Session;

typedef struct {
    int used;
    char email[160];
    char code[8];
    time_t expires;
} PendingOTP;

static PendingOTP pending_otps[MAX_SESSIONS];
static Session sessions[MAX_SESSIONS];
static char last_event[4096] = "{\"id\":0,\"sequence\":\"waiting\",\"file\":\"-\",\"fd\":-1,\"bytes\":0,\"result\":\"WAITING\",\"actor\":\"-\"}";
static unsigned long event_id = 0;

static void ensure_dir(const char *p) { mkdir(p,0755); }
static void ensure_storage(void) {
    ensure_dir("data"); ensure_dir("data/assignments"); ensure_dir("data/submissions");
    ensure_dir("data/versions");
}
static void set_event(const char *seq,const char *file,int fd,long bytes,const char *result,const char *actor) {
    event_id++;
    snprintf(last_event,sizeof(last_event),
      "{\"id\":%lu,\"sequence\":\"%s\",\"file\":\"%s\",\"fd\":%d,\"bytes\":%ld,\"result\":\"%s\",\"actor\":\"%s\"}",
      event_id,seq,file,fd,bytes,result,actor?actor:"-");
}
static void send_http(int c,const char *status,const char *type,const char *body,const char *extra) {
    char h[2048]; size_t len=strlen(body);
    int n=snprintf(h,sizeof(h),"HTTP/1.1 %s\r\nContent-Type: %s; charset=utf-8\r\nContent-Length: %zu\r\n"
      "Access-Control-Allow-Origin: *\r\nAccess-Control-Allow-Headers: Content-Type, X-Session-Token\r\n"
      "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\nCache-Control: no-store\r\nConnection: close\r\n%s\r\n",
      status,type,len,extra?extra:"");
    send(c,h,n,0); send(c,body,len,0);
}
static void json(int c,const char *body){ send_http(c,"200 OK","application/json",body,NULL); }
static void err(int c,const char *msg){ char b[1024]; snprintf(b,sizeof(b),"{\"ok\":false,\"error\":\"%s\"}",msg); send_http(c,"400 Bad Request","application/json",b,NULL); }

static int receive_request(int c,char *buf,int cap) {
    int total=0,cl=0;
    while(total<cap-1){
        int n=recv(c,buf+total,cap-total-1,0); if(n<=0) return -1;
        total+=n; buf[total]='\0';
        char *end=strstr(buf,"\r\n\r\n"); if(!end) continue;
        char *p=strstr(buf,"Content-Length:"); if(p) sscanf(p,"Content-Length: %d",&cl);
        int hl=(int)(end+4-buf);
        while(total-hl<cl && total<cap-1){ n=recv(c,buf+total,cap-total-1,0); if(n<=0) break; total+=n; buf[total]='\0'; }
        return hl;
    } return -1;
}
static int json_string_param(const char *body,const char *key,char *out,size_t cap){
    char needle[128]; snprintf(needle,sizeof(needle),"\"%s\"",key);
    const char *p=strstr(body,needle); if(!p) return 0; p=strchr(p+strlen(needle),':'); if(!p) return 0; p++;
    while(*p==' '||*p=='\t')p++; if(*p!='"') return 0; p++; size_t i=0;
    while(*p&&*p!='"'&&i+1<cap){ if(*p=='\\'&&p[1]){p++; if(*p=='n')out[i++]='\n'; else if(*p=='r')out[i++]='\r'; else out[i++]=*p; p++;} else out[i++]=*p++; }
    out[i]='\0'; return 1;
}
static int int_param(const char *body,const char *key,int fallback){
    char needle[128]; snprintf(needle,sizeof(needle),"\"%s\"",key); char *p=(char*)strstr(body,needle); if(!p)return fallback;
    p=strchr(p+strlen(needle),':'); if(!p)return fallback; return atoi(p+1);
}
static void esc(char *out,size_t cap,const char *s){
    size_t j=0; for(const char*p=s;*p&&j+4<cap;p++){ if(*p=='\\'||*p=='"')out[j++]='\\';
      if(*p=='\n'){out[j++]='\\';out[j++]='n';} else if(*p=='\r'){out[j++]='\\';out[j++]='r';} else out[j++]=*p; } out[j]='\0';
}
static int safe_field(const char *s){ if(!s||!*s)return 0; for(const char*p=s;*p;p++) if(*p=='|'||*p=='\n'||*p=='\r'||*p=='\\')return 0; return 1; }
static int safe_name(const char *in,char *out,size_t cap){
    size_t j=0; for(const char*p=in;*p&&j+1<cap;p++){ if(*p=='/'||*p=='\\'||*p=='.'||*p==':'||*p==' ')return 0; out[j++]=*p; } out[j]='\0'; return j>0;
}

static int find_session(const char *token){
    if(!token||!*token)return -1; for(int i=0;i<MAX_SESSIONS;i++) if(sessions[i].used&&!strcmp(sessions[i].token,token))return i; return -1;
}
static int header_token(const char *req,char *out,size_t cap){
    const char *p=strstr(req,"X-Session-Token:"); if(!p)return 0; p+=16; while(*p==' ')p++;
    size_t i=0; while(*p&&*p!='\r'&&*p!='\n'&&i+1<cap)out[i++]=*p++; out[i]='\0'; return i>0;
}
static int auth(const char *req,int c,const char *role){
    char tok[80]; if(!header_token(req,tok,sizeof(tok))){err(c,"Please sign in.");return -1;}
    int s=find_session(tok); if(s<0){err(c,"Session expired. Please sign in again.");return -1;}
    if(role && strcmp(sessions[s].role,role)){err(c,"This action is restricted to the other portal.");return -1;}
    return s;
}
static void make_token(char *out,size_t cap){
    static unsigned long seq=0; seq++; snprintf(out,cap,"%lx%lx%lx",(unsigned long)time(NULL),seq,(unsigned long)getpid());
}
static int user_find(const char *email,char *name,size_t nc,char *id,size_t ic,char *dept,size_t dc,char *role,size_t rc,char *pass,size_t pc){
    int fd=open("data/users.db",O_RDONLY); if(fd<0)return 0;
    char buf[65536]; ssize_t n=read(fd,buf,sizeof(buf)-1); close(fd); if(n<=0)return 0; buf[n]='\0';
    char *save_line=NULL;
    char *line=strtok_r(buf,"\n",&save_line);
    while(line){
        char tmp[800]; snprintf(tmp,sizeof(tmp),"%s",line);
        char *save=NULL;
        char *a=strtok_r(tmp,"|",&save), *b=strtok_r(NULL,"|",&save), *c=strtok_r(NULL,"|",&save),
             *d=strtok_r(NULL,"|",&save), *e=strtok_r(NULL,"|",&save), *f=strtok_r(NULL,"|",&save);
        if(a&&b&&c&&d&&e&&f&&!strcmp(a,email)){
            snprintf(pass,pc,"%s",b); snprintf(name,nc,"%s",c); snprintf(id,ic,"%s",d);
            snprintf(dept,dc,"%s",e); snprintf(role,rc,"%s",f); return 1;
        }
        line=strtok_r(NULL,"\n",&save_line);
    }
    return 0;
}
static int user_exists(const char *email){char a[8],b[8],c[8],d[8],e[8],f[32];return user_find(email,c,8,d,8,e,8,f,32,a,8);}
static int write_append(const char *path,const char *line){
    int fd=open(path,O_CREAT|O_WRONLY|O_APPEND,0644); if(fd<0)return -1; ssize_t n=write(fd,line,strlen(line)); close(fd); return n<0?-1:0;
}
static int load_assignment_ids(int *ids, int cap){
    DIR *d=opendir("data/assignments"); if(!d)return 0;
    struct dirent *ent; int n=0;
    while((ent=readdir(d))!=NULL){
        int id=0; char extra;
        if(sscanf(ent->d_name,"%d.meta%c",&id,&extra)==1 && id>0 && n<cap) ids[n++]=id;
    }
    closedir(d);
    for(int i=0;i<n;i++) for(int j=i+1;j<n;j++) if(ids[j]<ids[i]){int t=ids[i];ids[i]=ids[j];ids[j]=t;}
    return n;
}
static int next_assignment_id(void){
    int ids[4096]; int n=load_assignment_ids(ids,4096); int candidate=1;
    for(int i=0;i<n;i++){ if(ids[i]==candidate) candidate++; else if(ids[i]>candidate) break; }
    return candidate;
}
static int load_assignment(int id,char *title,size_t tc,char *course,size_t cc,char *due,size_t dc,char *email,size_t ec,char *faculty,size_t fc,char *published,size_t pc){
    char path[256],line[1024];snprintf(path,sizeof(path),"data/assignments/%d.meta",id);int fd=open(path,O_RDONLY);if(fd<0)return 0;
    ssize_t n=read(fd,line,sizeof(line)-1);close(fd);if(n<=0)return 0;line[n]='\0';
    char *x=strtok(line,"|"),*a=strtok(NULL,"|"),*b=strtok(NULL,"|"),*c=strtok(NULL,"|"),*d=strtok(NULL,"|"),*e=strtok(NULL,"|");
    if(!x||!a||!b||!c||!d||!e)return 0;
    snprintf(title,tc,"%s",x);snprintf(course,cc,"%s",a);snprintf(due,dc,"%s",b);snprintf(email,ec,"%s",c);snprintf(faculty,fc,"%s",d);snprintf(published,pc,"%s",e); published[strcspn(published,"\r\n")]=0; return 1;
}
static int submission_path(int aid,const char *email,char *out,size_t cap){
    char clean[160];size_t j=0;for(const char*p=email;*p&&j+1<sizeof(clean);p++){if((*p>='a'&&*p<='z')||(*p>='A'&&*p<='Z')||(*p>='0'&&*p<='9'))clean[j++]=*p;else clean[j++]='_';}clean[j]='\0';
    snprintf(out,cap,"data/submissions/%d_%s.txt",aid,clean);return 1;
}
static int copy_file(const char *src,const char *dst,const char *actor,const char *eventfile){
    int a=open(src,O_RDONLY);if(a<0)return -1;int b=open(dst,O_CREAT|O_WRONLY|O_TRUNC,0644);if(b<0){close(a);return -1;}
    char buf[8192];ssize_t n,total=0;while((n=read(a,buf,sizeof(buf)))>0){if(write(b,buf,n)!=n){close(a);close(b);return -1;}total+=n;}close(a);close(b);
    set_event("open() -> read() -> write() -> close()",eventfile,b,total,"ARCHIVED",actor);return 0;
}

static void make_otp(char *out,size_t cap){
    unsigned int x=(unsigned int)time(NULL) ^ (unsigned int)getpid() ^ (unsigned int)rand();
    snprintf(out,cap,"%06u",x%1000000u);
}
static int otp_slot(const char *email){
    for(int i=0;i<MAX_SESSIONS;i++) if(pending_otps[i].used && !strcmp(pending_otps[i].email,email)) return i;
    for(int i=0;i<MAX_SESSIONS;i++) if(!pending_otps[i].used) return i;
    return -1;
}
static void api_request_otp(int c,const char *body){
    char email[160];
    if(!json_string_param(body,"email",email,sizeof(email))||!safe_field(email)){err(c,"Enter a valid college email.");return;}
    if(user_exists(email)){err(c,"An account with this email already exists.");return;}
    int slot=otp_slot(email); if(slot<0){err(c,"OTP service is busy. Try again.");return;}
    pending_otps[slot].used=1; snprintf(pending_otps[slot].email,sizeof(pending_otps[slot].email),"%s",email);
    make_otp(pending_otps[slot].code,sizeof(pending_otps[slot].code)); pending_otps[slot].expires=time(NULL)+300;
    char out[500]; snprintf(out,sizeof(out),"{\"ok\":true,\"demo_otp\":\"%s\",\"expires_in\":300}",pending_otps[slot].code); json(c,out);
}
static int verify_pending_otp(const char *email,const char *code){
    for(int i=0;i<MAX_SESSIONS;i++){
        if(pending_otps[i].used && !strcmp(pending_otps[i].email,email)){
            if(time(NULL)>pending_otps[i].expires) {pending_otps[i].used=0; return 0;}
            if(!strcmp(pending_otps[i].code,code)){pending_otps[i].used=0; return 1;}
            return 0;
        }
    }
    return 0;
}
static void api_signup(int c,const char *body){
    char name[120],email[160],id[80],dept[100],role[24],pass[120],otp[16]={0};
    if(!json_string_param(body,"name",name,sizeof(name))||!json_string_param(body,"email",email,sizeof(email))||
       !json_string_param(body,"id",id,sizeof(id))||!json_string_param(body,"department",dept,sizeof(dept))||
       !json_string_param(body,"role",role,sizeof(role))||!json_string_param(body,"password",pass,sizeof(pass))||!json_string_param(body,"otp",otp,sizeof(otp))||
       !safe_field(name)||!safe_field(email)||!safe_field(id)||!safe_field(dept)||!safe_field(pass)||
       (strcmp(role,"Student")&&strcmp(role,"Faculty"))){err(c,"Please complete all fields with a valid role.");return;}
    if(user_exists(email)){err(c,"An account with this email already exists.");return;}
    if(!verify_pending_otp(email,otp)){err(c,"Invalid or expired OTP. Request a new code.");return;}
    char line[700];snprintf(line,sizeof(line),"%s|%s|%s|%s|%s|%s\n",email,pass,name,id,dept,role);
    if(write_append("data/users.db",line)<0){err(c,"Could not create account.");return;}
    json(c,"{\"ok\":true}");
}
static void api_login(int c,const char *body){
    char email[160],pass[120],name[120],id[80],dept[100],role[24],stored[120];
    if(!json_string_param(body,"email",email,sizeof(email))||!json_string_param(body,"password",pass,sizeof(pass))||!user_find(email,name,sizeof(name),id,sizeof(id),dept,sizeof(dept),role,sizeof(role),stored,sizeof(stored))||strcmp(pass,stored)){err(c,"Invalid email or password.");return;}
    int slot=-1;for(int i=0;i<MAX_SESSIONS;i++)if(!sessions[i].used){slot=i;break;}if(slot<0){err(c,"Session capacity reached.");return;}
    sessions[slot].used=1;make_token(sessions[slot].token,sizeof(sessions[slot].token));snprintf(sessions[slot].email,sizeof(sessions[slot].email),"%s",email);
    snprintf(sessions[slot].name,sizeof(sessions[slot].name),"%s",name);snprintf(sessions[slot].role,sizeof(sessions[slot].role),"%s",role);
    char out[900];snprintf(out,sizeof(out),"{\"ok\":true,\"token\":\"%s\",\"user\":{\"name\":\"%s\",\"email\":\"%s\",\"id\":\"%s\",\"department\":\"%s\",\"role\":\"%s\"}}",
      sessions[slot].token,name,email,id,dept,role);json(c,out);
}
static void api_logout(int c,const char *req){char tok[80];if(header_token(req,tok,sizeof(tok))){int s=find_session(tok);if(s>=0)sessions[s].used=0;}json(c,"{\"ok\":true}");}
static void api_me(int c,const char *req){int s=auth(req,c,NULL);if(s<0)return;char id[80],dept[100],pass[120],role[24],name[120];if(!user_find(sessions[s].email,name,sizeof(name),id,sizeof(id),dept,sizeof(dept),role,sizeof(role),pass,sizeof(pass))){err(c,"User not found.");return;}
    char out[700];snprintf(out,sizeof(out),"{\"ok\":true,\"user\":{\"name\":\"%s\",\"email\":\"%s\",\"id\":\"%s\",\"department\":\"%s\",\"role\":\"%s\"}}",name,sessions[s].email,id,dept,role);json(c,out);
}
static void api_assignments(int c,const char *req){
    int s=auth(req,c,NULL);if(s<0)return;char out[30000]="{\"ok\":true,\"assignments\":[";
    int ids[4096],count=load_assignment_ids(ids,4096),first=1;
    for(int k=0;k<count;k++){int id=ids[k];char t[180],co[100],due[40],em[160],fn[120],pub[20];if(!load_assignment(id,t,sizeof(t),co,sizeof(co),due,sizeof(due),em,sizeof(em),fn,sizeof(fn),pub,sizeof(pub)))continue;
      if(strcmp(pub,"1")&&!strcmp(sessions[s].role,"Student"))continue;
      char descpath[256],desc[6000]={0},row[9000];snprintf(descpath,sizeof(descpath),"data/assignments/%d.desc",id);int fd=open(descpath,O_RDONLY);if(fd>=0){ssize_t n=read(fd,desc,sizeof(desc)-1);close(fd);if(n>0)desc[n]='\0';}
      char ed[7000];esc(ed,sizeof(ed),desc);int submitted=0;char sp[256];submission_path(id,sessions[s].email,sp,sizeof(sp));struct stat st;if(stat(sp,&st)==0)submitted=1;
      snprintf(row,sizeof(row),"%s{\"id\":%d,\"title\":\"%s\",\"course\":\"%s\",\"due\":\"%s\",\"faculty\":\"%s\",\"description\":\"%s\",\"submitted\":%s}",first?"":",",id,t,co,due,fn,ed,submitted?"true":"false");
      strncat(out,row,sizeof(out)-strlen(out)-1);first=0;
    }strncat(out,"]}",sizeof(out)-strlen(out)-1);json(c,out);
}

static void api_assignment_create(int c,const char *req,const char *body){
    int s=auth(req,c,"Faculty");if(s<0)return;char title[180],course[100],due[40],desc[6000];
    if(!json_string_param(body,"title",title,sizeof(title))||!json_string_param(body,"course",course,sizeof(course))||!json_string_param(body,"due",due,sizeof(due))||!json_string_param(body,"description",desc,sizeof(desc))||!safe_field(title)||!safe_field(course)||!safe_field(due)){err(c,"Complete the assignment fields.");return;}
    int existing_ids[4096],existing_count=load_assignment_ids(existing_ids,4096); for(int k=0;k<existing_count;k++){char et[180],eco[100],edue[40],eem[160],efn[120],epub[20]; if(load_assignment(existing_ids[k],et,sizeof(et),eco,sizeof(eco),edue,sizeof(edue),eem,sizeof(eem),efn,sizeof(efn),epub,sizeof(epub)) && !strcmp(eem,sessions[s].email) && !strcmp(et,title) && !strcmp(eco,course) && !strcmp(edue,due)){err(c,"An identical assignment already exists. Open Assignments to view it."); return;}} int id=next_assignment_id();char meta[1024],mp[256],dp[256];snprintf(mp,sizeof(mp),"data/assignments/%d.meta",id);snprintf(dp,sizeof(dp),"data/assignments/%d.desc",id);
    int fd=open(mp,O_CREAT|O_WRONLY|O_TRUNC,0644);if(fd<0){err(c,"Could not create assignment.");return;}snprintf(meta,sizeof(meta),"%s|%s|%s|%s|%s|1\n",title,course,due,sessions[s].email,sessions[s].name);write(fd,meta,strlen(meta));close(fd);
    fd=open(dp,O_CREAT|O_WRONLY|O_TRUNC,0644);if(fd<0){err(c,"Could not create description.");return;}write(fd,desc,strlen(desc));close(fd);
    char label[128];snprintf(label,sizeof(label),"assignment_%d.meta",id);set_event("open(O_CREAT|O_TRUNC) -> write() -> close()",label,fd,(long)strlen(meta),"SUCCESS",sessions[s].name);
    char out[300];snprintf(out,sizeof(out),"{\"ok\":true,\"id\":%d}",id);json(c,out);
}
static void api_assignment_delete(int c,const char *req,const char *body){
    int s=auth(req,c,"Faculty");if(s<0)return;int id=int_param(body,"id",0);char t[180],co[100],due[40],em[160],fn[120],pub[20];if(id<1||!load_assignment(id,t,sizeof(t),co,sizeof(co),due,sizeof(due),em,sizeof(em),fn,sizeof(fn),pub,sizeof(pub))){err(c,"Assignment not found.");return;}
    if(strcmp(em,sessions[s].email)){err(c,"You can only delete your own assignments.");return;}
    char p[256];snprintf(p,sizeof(p),"data/assignments/%d.meta",id);if(unlink(p)!=0){err(c,"Could not delete assignment.");return;}snprintf(p,sizeof(p),"data/assignments/%d.desc",id);unlink(p);set_event("unlink()",t,-1,0,"SUCCESS",sessions[s].name);json(c,"{\"ok\":true}");
}
static void api_submission_submit(int c,const char *req,const char *body){
    int s=auth(req,c,"Student");if(s<0)return;int id=int_param(body,"assignment_id",0);char content[50000];if(!json_string_param(body,"content",content,sizeof(content))){err(c,"Submission content is missing.");return;}
    char t[180],co[100],due[40],em[160],fn[120],pub[20];if(!load_assignment(id,t,sizeof(t),co,sizeof(co),due,sizeof(due),em,sizeof(em),fn,sizeof(fn),pub,sizeof(pub))||strcmp(pub,"1")){err(c,"Assignment not found.");return;}
    char path[256];submission_path(id,sessions[s].email,path,sizeof(path));struct stat st;int replacing=stat(path,&st)==0;
    if(replacing){char arch[256];int v=1;for(;v<1000;v++){snprintf(arch,sizeof(arch),"data/versions/%d_%s_v%d.txt",id,sessions[s].email,v);if(stat(arch,&st)!=0)break;}if(copy_file(path,arch,sessions[s].name,arch)!=0){err(c,"Could not archive previous submission.");return;}}
    int fd=open(path,O_CREAT|O_WRONLY|O_TRUNC,0644);if(fd<0){err(c,"Could not open submission.");return;}ssize_t n=write(fd,content,strlen(content));close(fd);
    set_event(replacing?"open(O_TRUNC) -> write() -> close()":"open(O_CREAT|O_TRUNC) -> write() -> close()",path,fd,n>=0?n:0,n>=0?"SUCCESS":"ERROR",sessions[s].name);
    if(n<0){err(c,"Linux write() failed.");return;}char out[256];snprintf(out,sizeof(out),"{\"ok\":true,\"bytes\":%ld}",(long)n);json(c,out);
}
static void api_submission_read(int c,const char *req,const char *body){
    int s=auth(req,c,NULL);if(s<0)return;int id=int_param(body,"assignment_id",0);char email[160];json_string_param(body,"email",email,sizeof(email));
    char t[180],co[100],due[40],em[160],fn[120],pub[20];if(!load_assignment(id,t,sizeof(t),co,sizeof(co),due,sizeof(due),em,sizeof(em),fn,sizeof(fn),pub,sizeof(pub))){err(c,"Assignment not found.");return;}
    if(!strcmp(sessions[s].role,"Student"))snprintf(email,sizeof(email),"%s",sessions[s].email);else if(!email[0]){err(c,"Student email required.");return;}
    if(!strcmp(sessions[s].role,"Faculty") && strcmp(em,sessions[s].email)){err(c,"You can only inspect submissions for your assignment.");return;}
    char path[256];submission_path(id,email,path,sizeof(path));int fd=open(path,O_RDONLY);if(fd<0){err(c,"No submission found.");return;}struct stat st;fstat(fd,&st);char *data=malloc(st.st_size+1);if(!data){close(fd);err(c,"Memory allocation failed.");return;}ssize_t n=read(fd,data,st.st_size);close(fd);data[n>0?n:0]='\0';
    char *e=malloc((n>0?n:1)*2+1024);char *o=malloc((n>0?n:1)*2+1300);if(!e||!o){free(data);free(e);free(o);err(c,"Memory allocation failed.");return;}esc(e,(n>0?n:1)*2+1024,data);
    char student[120]="";char id2[80],dept[100],role[24],pass[120];user_find(email,student,sizeof(student),id2,sizeof(id2),dept,sizeof(dept),role,sizeof(role),pass,sizeof(pass));
    snprintf(o,(n>0?n:1)*2+1300,"{\"ok\":true,\"assignment_id\":%d,\"email\":\"%s\",\"student\":\"%s\",\"fd\":%d,\"bytes\":%ld,\"content\":\"%s\"}",id,email,student,fd,(long)n,e);json(c,o);free(data);free(e);free(o);
    set_event("open() -> read() -> close()",path,fd,n,"SUCCESS",sessions[s].name);
}
static void api_submissions(int c,const char *req,const char *body){
    int s=auth(req,c,"Faculty"); if(s<0)return;
    int id=int_param(body,"assignment_id",0);
    char t[180],co[100],due[40],em[160],fn[120],pub[20];
    if(!load_assignment(id,t,sizeof(t),co,sizeof(co),due,sizeof(due),em,sizeof(em),fn,sizeof(fn),pub,sizeof(pub))||strcmp(em,sessions[s].email)){
        err(c,"Assignment not found or not owned by you."); return;
    }
    int fd=open("data/users.db",O_RDONLY);
    if(fd<0){json(c,"{\"ok\":true,\"submissions\":[]}");return;}
    char ub[65536]; ssize_t un=read(fd,ub,sizeof(ub)-1); close(fd); if(un<0)un=0; ub[un]='\0';
    char out[30000]="{\"ok\":true,\"submissions\":["; int first=1; struct stat st;
    char *save_line=NULL; char *line=strtok_r(ub,"\n",&save_line);
    while(line){
        char tmp[800]; snprintf(tmp,sizeof(tmp),"%s",line); char *save=NULL;
        char *e=strtok_r(tmp,"|",&save),*pw=strtok_r(NULL,"|",&save),*nm=strtok_r(NULL,"|",&save),
             *uid=strtok_r(NULL,"|",&save),*dep=strtok_r(NULL,"|",&save),*rl=strtok_r(NULL,"|",&save);
        (void)pw;(void)uid;(void)dep;
        if(e&&nm&&rl&&!strcmp(rl,"Student")){
            char sp[256]; submission_path(id,e,sp,sizeof(sp));
            if(stat(sp,&st)==0){
                char row[600]; snprintf(row,sizeof(row),"%s{\"email\":\"%s\",\"student\":\"%s\",\"bytes\":%ld}",first?"":",",e,nm,(long)st.st_size);
                strncat(out,row,sizeof(out)-strlen(out)-1); first=0;
            }
        }
        line=strtok_r(NULL,"\n",&save_line);
    }
    strncat(out,"]}",sizeof(out)-strlen(out)-1); json(c,out);
}
static void api_notes(int c,const char *req,const char *body){
    int s=auth(req,c,NULL);if(s<0)return; char action[32]; if(json_string_param(body,"action",action,sizeof(action)) && !strcmp(action,"READ")){int fd=open("data/shared_notes.txt",O_RDONLY);if(fd<0){json(c,"{\"ok\":true,\"content\":\"\"}");return;}char b[30000];ssize_t n=read(fd,b,sizeof(b)-1);close(fd);b[n>0?n:0]='\0';char e[60000];esc(e,sizeof(e),b);char o[61000];snprintf(o,sizeof(o),"{\"ok\":true,\"content\":\"%s\"}",e);json(c,o);set_event("open() -> read() -> close()","shared_notes.txt",fd,n,"SUCCESS",sessions[s].name);return;}
    char content[12000];if(!json_string_param(body,"content",content,sizeof(content))){err(c,"Note content missing.");return;}char line[13000];snprintf(line,sizeof(line),"%s: %s\n",sessions[s].name,content);int fd=open("data/shared_notes.txt",O_CREAT|O_WRONLY|O_APPEND,0644);if(fd<0){err(c,"Could not open notes.");return;}ssize_t n=write(fd,line,strlen(line));close(fd);set_event("open(O_APPEND) -> write() -> close()","shared_notes.txt",fd,n,"SUCCESS",sessions[s].name);json(c,"{\"ok\":true}");
}
static void api_io(int c,const char *req){if(auth(req,c,NULL)<0)return;char o[5000];snprintf(o,sizeof(o),"{\"ok\":true,\"event\":%s}",last_event);json(c,o);}
static void api_files(int c,const char *req){
    int s=auth(req,c,NULL);if(s<0)return;char out[30000]="{\"ok\":true,\"files\":[";int first=1;struct stat st;
    int ids[4096],count=load_assignment_ids(ids,4096);
    for(int k=0;k<count;k++){int id=ids[k];char t[180],co[100],due[40],em[160],fn[120],pub[20];if(!load_assignment(id,t,sizeof(t),co,sizeof(co),due,sizeof(due),em,sizeof(em),fn,sizeof(fn),pub,sizeof(pub)))continue;
      if(strcmp(pub,"1")&&!strcmp(sessions[s].role,"Student"))continue;char row[700];snprintf(row,sizeof(row),"%s{\"name\":\"Assignment %d — %s\",\"type\":\"assignment\",\"size\":%ld,\"permissions\":\"0644\"}",first?"":",",id,t,(long)strlen(t));strncat(out,row,sizeof(out)-strlen(out)-1);first=0;}
    if(!strcmp(sessions[s].role,"Student")){for(int k=0;k<count;k++){int id=ids[k];char t[180],co[100],due[40],em[160],fn[120],pub[20];if(!load_assignment(id,t,sizeof(t),co,sizeof(co),due,sizeof(due),em,sizeof(em),fn,sizeof(fn),pub,sizeof(pub))||strcmp(pub,"1"))continue;char sp[256];submission_path(id,sessions[s].email,sp,sizeof(sp));if(stat(sp,&st)==0){char row[700];snprintf(row,sizeof(row),",{\"name\":\"Submission %d — %s\",\"type\":\"submission\",\"size\":%ld,\"permissions\":\"0644\"}",id,t,(long)st.st_size);strncat(out,row,sizeof(out)-strlen(out)-1);}}}
    strncat(out,"]}",sizeof(out)-strlen(out)-1);json(c,out);
}
static void serve_static(int c,const char *path){
    const char *file=NULL,*type="text/plain";if(!strcmp(path,"/")||!strcmp(path,"/index.html")){file="public/index.html";type="text/html";}else if(!strcmp(path,"/style.css")){file="public/style.css";type="text/css";}else if(!strcmp(path,"/app.js")){file="public/app.js";type="application/javascript";}else{send_http(c,"404 Not Found","text/plain","Not found",NULL);return;}
    int fd=open(file,O_RDONLY);if(fd<0){send_http(c,"404 Not Found","text/plain","Asset not found",NULL);return;}struct stat st;fstat(fd,&st);char *data=malloc(st.st_size+1);if(!data){close(fd);return;}ssize_t n=read(fd,data,st.st_size);close(fd);data[n>0?n:0]='\0';send_http(c,"200 OK",type,data,NULL);free(data);
}
static void handle(int c){
    char req[REQUEST_MAX]={0};int hl=receive_request(c,req,sizeof(req));if(hl<0){close(c);return;}char method[16]={0},path[256]={0};sscanf(req,"%15s %255s",method,path);char *q=strchr(path,'?');if(q)*q='\0';const char *body=req+hl;
    if(!strcmp(method,"OPTIONS"))send_http(c,"200 OK","text/plain","",NULL);
    else if(!strcmp(method,"POST")&&!strcmp(path,"/api/auth/request-otp"))api_request_otp(c,body);
    else if(!strcmp(method,"POST")&&!strcmp(path,"/api/auth/signup"))api_signup(c,body);
    else if(!strcmp(method,"POST")&&!strcmp(path,"/api/auth/login"))api_login(c,body);
    else if(!strcmp(method,"POST")&&!strcmp(path,"/api/auth/logout"))api_logout(c,req);
    else if(!strcmp(method,"GET")&&!strcmp(path,"/api/auth/me"))api_me(c,req);
    else if(!strcmp(method,"GET")&&!strcmp(path,"/api/assignments"))api_assignments(c,req);
    else if(!strcmp(method,"POST")&&!strcmp(path,"/api/assignments/create"))api_assignment_create(c,req,body);
    else if(!strcmp(method,"POST")&&!strcmp(path,"/api/assignments/delete"))api_assignment_delete(c,req,body);
    else if(!strcmp(method,"POST")&&!strcmp(path,"/api/submissions/submit"))api_submission_submit(c,req,body);
    else if(!strcmp(method,"POST")&&!strcmp(path,"/api/submissions/read"))api_submission_read(c,req,body);
    else if(!strcmp(method,"POST")&&!strcmp(path,"/api/submissions/list"))api_submissions(c,req,body);
    else if(!strcmp(method,"POST")&&!strcmp(path,"/api/notes"))api_notes(c,req,body);
    else if(!strcmp(method,"GET")&&!strcmp(path,"/api/io"))api_io(c,req);
    else if(!strcmp(method,"GET")&&!strcmp(path,"/api/files"))api_files(c,req);
    else serve_static(c,path);
    close(c);
}
int main(void){
    signal(SIGPIPE,SIG_IGN);ensure_storage();int server=socket(AF_INET,SOCK_STREAM,0);int yes=1;setsockopt(server,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(yes));
    struct sockaddr_in a={0};a.sin_family=AF_INET;a.sin_addr.s_addr=htonl(INADDR_ANY);a.sin_port=htons(PORT);
    if(bind(server,(struct sockaddr*)&a,sizeof(a))<0){perror("bind");return 1;}if(listen(server,32)<0){perror("listen");return 1;}
    printf("CampusHub Faculty + Student Portal running at http://localhost:%d\n",PORT);fflush(stdout);while(1){int c=accept(server,NULL,NULL);if(c>=0)handle(c);}return 0;
}
