CampusHub — Faculty + Student Portal
====================================

Features
- Separate Faculty and Student portals
- Signup with 6-digit OTP verification (local demo OTP; no external email service required)
- Role-based login
- Faculty assignment creation/publishing and submission review
- Student assignment viewing and submission/replacement
- Shared Notes using O_APPEND
- Academic Files view
- File Descriptor / I/O Monitor
- Dark / Light mode with saved preference
- Guided authentication flow: Create account -> Verify OTP -> Enter role portal

Linux mechanisms demonstrated
open(), read(), write(), close(), lseek(), dup(), stat(), unlink()
O_CREAT, O_TRUNC, O_APPEND

Run on Ubuntu/WSL
1. cd /mnt/c/Users/Admin/Downloads
2. unzip CampusHub_Faculty_Student_Portal_OTP_THEME.zip -d CampusHub_OTP_THEME
3. cd CampusHub_OTP_THEME
4. gcc -O2 server.c -o campushub
5. ./campushub
6. Open http://localhost:8080

OTP note
This project is a local academic demo and does not send real email/SMS. The generated OTP is displayed in the signup screen so the verification flow can be demonstrated without an external provider.
